<?php

$cmd = "cat /proc/net/serval/service_table";

$s = exec($cmd, $out, $return_val);

foreach ($out as $o) {
  echo $o."<br>";
}

?>