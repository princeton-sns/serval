<html>
<head><title>Controller</title></head>
<body>

<form action="service_handler.php" method="post">

   Prefix:
   <input type="text" name="prefix"><br>
   
   Destination Address:
   <input type="test" name="dstIP"><br>

   <select name="machineList">
      <option>Please select your machine</option>
      <option>SNS1</option>
      <option>SNS2</option>
      <option>SNS3</option>
      <option>SNS4</option>
   </select>

   <p></p>

   <input type="submit" value="submit">

   
</form>

</body>
<html>