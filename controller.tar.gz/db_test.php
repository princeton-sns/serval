<?php
require('db.php');

$db = get_serval_db();

$router_name = "sns1";
$router_ip = "128.112.7.80";
$prefix = "1234";
$ip = "1.1.1.1";

#insert_service($db, $router_name, $router_ip, $prefix, $ip);

remove_service($db, $router_name, $prefix, $ip);

?>