<html>
<head><title>Serval Controller</title></head>
<body>

<form action="login.php" method="post">

User name:
<input type="text" name="username"><br>

Password:
<input type="password" name="password"><br>

<input type="submit" value="submit">

</form>

</body>
</body>
